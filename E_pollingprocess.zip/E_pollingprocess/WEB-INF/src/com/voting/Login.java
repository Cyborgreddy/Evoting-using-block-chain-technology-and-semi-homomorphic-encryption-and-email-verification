package com.voting;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.database.conn.DBConnection;
import com.database.conn.Methods;

public class Login extends HttpServlet {
	public Login(){

		con = null;
		st = null;
		rs = null;
	}
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
			{
		String a_id = req.getParameter("voter_id");
	
		String submit  = req.getParameter("pwd");
		System.out.println("==="+a_id);
		System.out.println("The value of submit =="+submit);
		RequestDispatcher rd = null;
		boolean flag = false;
		HttpSession sessionid = req.getSession(true);
		sessionid.setAttribute("voter_id", a_id);
		/* FUNCTION CALL FOR CHECK OFFICER USERNAME AND PASSWORD */
		if(submit.equals("Enter To Vote")){
			String a_pass = req.getParameter("voter_pass");
			flag = Methods.Checkofficer(a_id, a_pass);


			System.out.println((new StringBuilder("Flag...")).append(flag).toString());
			if(flag)
			{
				resp.sendRedirect((new StringBuilder(String.valueOf(req.getContextPath()))).append("/Voters.jsp?voter_id="+a_id).toString());
			} 
			else
			{
				rd = req.getRequestDispatcher("/index.jsp");
				req.setAttribute("Status", "Sorry, your id and password is mismatched");
				rd.forward(req, resp);
			}

		} else if(submit.equals("Get Password")){
			
			String emailId ="" ,pwd="",message= "";
			String alphaNumerics = "1234567890";
			
			Statement stmt  ;
			boolean flag3 =false;
		
			for (int i = 0; i < 6; i++) 
			{
			    pwd+= alphaNumerics.charAt((int) (Math.random() * alphaNumerics.length()));
			}
			try{
		
			flag = Methods.addVoterPwd(a_id,pwd);
			emailId  = Methods.getVoterEmail(a_id);
			
			 message="Hi,\n Your Voter id is "+a_id+"\n\n\nYour Password is  :"+pwd+"\n\nUse the above Password while login ";

			boolean flag2=com.util.SendMailAttachment.sendPersonalizedMail(emailId,"Password Detials",message,"no");
			if(flag2)
			{
				resp.sendRedirect((new StringBuilder(String.valueOf(req.getContextPath()))).append("/index.jsp?voter_id="+a_id).toString());
			} 
			else
			{
				rd = req.getRequestDispatcher("/index.jsp");
				req.setAttribute("Status", "Sorry, your id is wrong");
				rd.forward(req, resp);
			}
		}catch(Exception e ){
			System.out.print(e);
		}
			}

		DBConnection.closeResoures(rs, st, con);
		System.out.println("connection closed");
			}
	Connection con;
	Statement st;
	ResultSet rs;
}
