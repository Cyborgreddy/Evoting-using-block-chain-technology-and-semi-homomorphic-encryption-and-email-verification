package com.officer;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.Date;
import java.util.Timer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;





public class Monitoring extends HttpServlet
{
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException
		{
	Boolean flag=false;
	System.out.println("its came inside monitoring servlet");
	

	try
	{

		String reqUrl=req.getParameter("reqUrl");
		System.out.println("submit>>>>>>>>>>>>>>>>>>>>>>"+reqUrl);


		RandomTimernew testTimertask = new RandomTimernew();
	    long interval =1 * 20 * 1000;
	    Timer testTimer = new Timer();
	    testTimer.schedule(testTimertask,1000,interval);
		
		
		RequestDispatcher rd=req.getRequestDispatcher("/Files/JSP/officer/Monitoring.jsp");
		rd.forward(req, resp);
		
	}
	catch(Exception e)
	{
		System.out.println(e);
		
	}
}
	

}
	
	
	

