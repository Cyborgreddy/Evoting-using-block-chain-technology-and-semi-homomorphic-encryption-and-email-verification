package com.officer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.manager.Admin;

import symmetric_AES.AESCrypt;

public class Retrieve extends HttpServlet 
{
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException
		{
	
	
	
	String retrieve=req.getParameter("reqUrl");
	System.out.println("retrieve action>>>>>>>>>>>>>>>>"+retrieve);
	
	try
	{
		
		boolean flaggs=false;
		boolean flag = false;
		
		String ftpserver = "ftp.drivehq.com";
        String ftpusername = "Snowwhite1";
        String ftppassword = "*Snowwhite*1";
   	
   	
		
   	  
    	 String dirToUploadFile="Evoting";
    	 ArrayList<Integer> boothno=new ArrayList<Integer>();
    	 
    	 
    	 boothno=Admin.getboothnos();
    	 System.out.println("..boothno is..............."+boothno);
    	 
    		int element;
	    	ArrayList<Integer> boothname=new ArrayList<Integer>();
	    	
	    	for(int j=0;j<boothno.size();j++)
	    	{
	    		
	    		element=	boothno.get(j);
	    		boothname.add(element);
	    	System.out.println("element is >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+element);
	    	
	    	String blockname = null;
		
	    	blockname = Admin.getrecordblock(element);
		
		
	
				System.out.println("blockname>>>>>>>>>>>>>"+blockname);
	    	
	    	
	    	
    	 
	
     
        
        flag = FileDownload.download(ftpserver, ftpusername, ftppassword,dirToUploadFile, blockname);
        
        if(flag)
		{
        	/* Decrypting the downloaded File(Starts) */
        	
        	
    	String src = "D:/Download/"+blockname;
        	
        	
        	
        //	String src=req.getRealPath("")+"/JSP/retrieve/"+blockname;
        	
        	
        	
        	
    	   byte[] buffer = new byte[1024];
  	        ZipInputStream zis = new ZipInputStream(new FileInputStream(src));
  	        System.out.println("zis>>>>>>>>>>>>>>>>>>>>>>"+zis);
  	        ZipEntry zipEntry = zis.getNextEntry();
  	        while(zipEntry != null){
  	            String fileName2 = zipEntry.getName();
  	            System.out.println("fileName2>>>>>>>>>>>>>>>>"+fileName2);
  	          
  	            File newFile = new File("D:/Download/" + fileName2);
  	            System.out.println("newfile>>>>>>>>>>>>>>>>>>>"+newFile);
  	            FileOutputStream fos = new FileOutputStream(newFile);
  	            System.out.println("fos>>>>>>>>>>>>>>>>>>>>"+fos);
  	            int len;
  	            while ((len = zis.read(buffer)) > 0) 
  	            {
  	                fos.write(buffer, 0, len);
  	            }
  	            fos.close();
  	            zipEntry = zis.getNextEntry();
  	        }
  	        zis.closeEntry();
  	        zis.close();
       	
       	
       	
	        String srcs = "D:/Download/"+element+"_"+"block"+".txt";
	        
	        
	        
	        
	        
	        
	        
	        
	        File file = new File(srcs);
			FileReader fileReader = new FileReader(file);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			StringBuffer stringBuffer = new StringBuffer();
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				stringBuffer.append(line);
				stringBuffer.append("\n");
			}
			fileReader.close();
			System.out.println("Contents of file:>>>>>>>");
			System.out.println(stringBuffer.toString());
	        
	        
        	
		String values=stringBuffer.toString();
		System.out.println("values>>>>>>>>>>>>"+values);
	
		String[] parts = values.split("_");
		
		System.out.println("parts>>>>>>>>>>>>"+parts);
		
		String ccodde=parts[0];
		System.out.println("ccodde>>>>>>>>>>>>"+ccodde);
		String bcode=parts[1];
		System.out.println("bcode>>>>>>>>>>>>"+bcode);
		String edc=parts[2];
		System.out.println("edc>>>>>>>>>>>>"+edc);
		String novote=parts[3];
		System.out.println("novote>>>>>>>>>>>>"+novote);
		
     //	boolean flags=Admin.insertblockname(record,zipblkame);
     	
     	
    	 flaggs=Admin.insertrecords(ccodde,bcode,edc,novote);
		}
        
        	if(flaggs)
        	{
        		RequestDispatcher rd=req.getRequestDispatcher("/Files/JSP/officer/Monitoring.jsp");
        		rd.forward(req, resp);
        		
        	}
        	
            	
		
		
		
		
		}
		
		
	}
	
	catch (Exception e) 
	{
		
		System.out.println(e);
		// TODO: handle exception
	}
	
	
	
	
}
}
